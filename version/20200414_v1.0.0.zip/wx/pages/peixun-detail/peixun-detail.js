var __CML__GLOBAL = require('../../static/js/manifest.js')
__CML__GLOBAL.Page = Page;
require('../../static/js/common.js')
require('../../static/js/pages/peixun-detail/peixun-detail.js')
