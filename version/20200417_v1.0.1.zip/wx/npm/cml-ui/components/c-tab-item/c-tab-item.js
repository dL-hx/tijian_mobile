var __CML__GLOBAL = require('../../../../static/js/manifest.js')
__CML__GLOBAL.Component = Component;
require('../../../../static/js/common.js')
require('../../../../static/js/npm/cml-ui/components/c-tab-item/c-tab-item.js')
