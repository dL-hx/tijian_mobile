var __CML__GLOBAL = require('/static/js/manifest.js')
__CML__GLOBAL.App = App;
require('/static/js/common.js')
require('/static/js/app.js')
